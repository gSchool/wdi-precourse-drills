$("p").click(function)(){
  alert("This is a paragraph!");
});
