<!DOCTYPE html>
  <head>
  Results for "Hackers"
  </head>
  <body>
    <h1>Results for "Hackers"</h1>
    <h2>Titles</h2>
    <p><img src="https://m.media-amazon.com/images/M/MV5BNmExMTkyYjItZTg0YS00NWYzLTkwMjItZWJiOWQ2M2ZkYjE4XkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_UX182_CR0,0,182,268_AL_.jpg" width="32" height="44"> <a href="README.md">Hackers</a> (1995)</p>
    <p><img src="https://m.media-amazon.com/images/M/MV5BNDg3OTE4NDAxNl5BMl5BanBnXkFtZTcwODY5NzYxMQ@@._V1_UY268_CR1,0,182,268_AL_.jpg" width="32" height="44"> <a href="README.md">2000 AD</a> (2000) aka "Hackers"</p>
    <p><img src="https://m.media-amazon.com/images/M/MV5BMjAyNTk4MDc1MF5BMl5BanBnXkFtZTgwNzk4NzMyMjE@._V1_UY268_CR68,0,182,268_AL_.jpg" width="32" height="44"> <a href="README.md">Hackers</a> (2001) (TV Episode) - Frontline (1983) (TV Series)</p>
    <p><img src="https://m.media-amazon.com/images/M/MV5BMTA2NjIxNTQ4MTdeQTJeQWpwZ15BbWU4MDMxMzMwMTQx._V1_UX182_CR0,0,182,268_AL_.jpg" width="32" height="44"> <a href="README.md">Hacker's Game</a> (2015) aka "The Hackers"</p>
    <h2>Keywords</h2>
    <p><img src="https://m.media-amazon.com/images/M/MV5BMTczNjg5Mzc0MV5BMl5BanBnXkFtZTcwODg0NTM2OQ@@._V1_UY317_CR19,0,214,317_AL_.jpg" width="32" height="44"> <a href="https://www.imdb.com/name/nm0009918/?ref_=nv_sr_1">Amy Acker</a> (Actress, <a href="README.md">Angel</a> (1999))</p>
    <p><img src="https://m.media-amazon.com/images/M/MV5BMTgwNzM1MTQ1OF5BMl5BanBnXkFtZTcwMDQ5MTU4OA@@._V1_UY317_CR12,0,214,317_AL_.jpg" width="32" height="44"> <a href="https://www.imdb.com/name/nm3216408/?ref_=nv_sr_1">Drew Van Acker</a> (Actor, <a href="README.md">Pretty Little Liars</a> (2010))</p>
    <p><img src="https://m.media-amazon.com/images/M/MV5BMTY0NjI1OTU3MF5BMl5BanBnXkFtZTYwNTgxNTcz._V1_UX214_CR0,0,214,317_AL_.jpg" width="32" height="44"> <a href="https://www.imdb.com/name/nm0004983/?ref_=nv_sr_1">Buddy Hackett</a> (Actor, <a href="README.md">The Little Mermaid</a> (1989))</p>
    <p><img src="https://m.media-amazon.com/images/M/MV5BNmQ0ZTQxYzktMjMyYS00NjUwLTkwZDctOTBjZmM5MzJhZGNhXkEyXkFqcGdeQXVyMjQwMDg0Ng@@._V1_UY317_CR32,0,214,317_AL_.jpg" width="32" height="44"> <a href="https://www.imdb.com/name/nm2278978/?ref_=nv_sr_1">Emily Wickersham</a> (Actress, <a href="README.md">I Am Number Four</a> (2011))</p>
    <h2>Companies</h2>
    <p>Douglas, Gorman, Rothacker & Wilhelm (DGRW)</p>
    <p>Crackerjack Management</p>
    <p>Bleeker Street Media</p>
    <p>Bleeker Street Entertainment</p>
    <h2>Category Search</h2>
    <ul>
      <li>All</li>
      <li>Name</li>
      <li>Title</li>
      <ul>
        <li>Movie</li>
        <li>TV</li>
        <li>TV Episode</li>
        <li>Video Game</li>
      </ul>
      <li>Character</li>
      <li>Company</li>
      <li>Keyword</li>
      <li>Plot Summaries</li>
      <li>Biographies</li>
      <li>Quotes</li>
    </ul>
    <h2>Additional Search Options</h2>
    <ul>
      <li>Advanced Search</li>
      <li>Advanced Title Search</li>
      <li>Advanced Name Search</li>
    </ul>
  </body>
</html>
